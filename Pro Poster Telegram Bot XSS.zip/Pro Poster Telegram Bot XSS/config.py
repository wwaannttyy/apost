API_ID = 29989922 #APP TELEGRAM ID - https://t.me/slivmens
API_HASH = "6aabe659c63e252f480068e15dd4844d" # APP TELEGRAM HASH - https://t.me/slivmens
BOT_TOKEN = "5407387141:AAFwuoveBIDnpgz_D6EvZR2KLPHC4on_m4U" # BOT API - https://t.me/slivmens
DATABASE_PATH = 'database.db'
OPEN_AI_KEY = 'API KEY' # OPEN AI KEY - https://t.me/slivmens


language_codes = {
    'Ukranian': 'украинский',
    'Russian': 'русский',
    'English': 'английский',
    'Indian': 'индийский',
    'Italian': 'итальянский',
    'Brasilian': 'бразильский',
    'Germany': 'немецкий',
    'Indonesian': 'индонезийский'
}
